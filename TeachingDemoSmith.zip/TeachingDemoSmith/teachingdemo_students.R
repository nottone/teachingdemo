rm(list = ls())

library(ggplot2)
library(dplyr)

# Read one dataset: Bridgeport
bridgeport <- read.csv("GreenGerberNickerson2003_bridgeport.csv")

# Let's take a look at the Bridgeport data
head(bridgeport)

# We want to know what percentage of people voted in treatment and
# what percentage of people voted in control. How would we do that?
treatment <- bridgeport |>
  filter(treat == "Treatment")

control <- bridgeport |>
  filter(treat == "Control")

mean(treatment$voted01)
mean(control$voted01)

ate <- mean(treatment$voted01) - mean(control$voted01)
print(ate)

# Okay, now we want to test whether this difference is significant
sims <- 1000
ates <- rep(NA, sims)

for(i in 1:sims){
  bridgeport$treat_new <- rbinom(n = nrow(bridgeport), size = 1, prob = 0.5)
  treated <- bridgeport |> 
    filter(treat_new == 1)
  control <- bridgeport |> 
    filter(treat_new == 0)
  ates[i] <- mean(treated$voted01) - mean(control$voted01)
}

# Plot the simulated differences as a histogram
ggplot(data.frame(ATE = ates), aes(x = ATE)) +
  geom_histogram() +
  geom_vline(xintercept = ate, color = "red", linetype = "dashed", size = 1) +
  labs(x = "Null Distribution", y = "Count") +
  annotate("text",
           x = ate - 0.012,
           y = 110,
           label = "ATE = 0.39", color = "red", size = rel(4)
  )

# How many simulations are more extreme than the estimated difference?
mean(ate <= ates) # for one-tailed
mean(ate <= abs(ates)) # for two-tailed

####################################
# Now you try with Columbus!
columbus <- read.csv("GreenGerberNickerson2003_columbus.csv")
head(columbus)

# First: Calculate the proportion of people in treatment who voted and the
# propotion of people in control who voted.




# Second: Take the difference between these two proportions. This is the 
# average treatment effect, or ATE. Store it as ate_columbus

ate_columbus

# Third: Run simulations that shuffle treatment to determine whether
# this average treatment effect is statistically significant
sims <- 1000
ates <- rep(NA, sims)


for(i in 1:sims){
  # First: simulate the treatment vector using rbinom. Use ?rbinom if you need help.
  # Make a new column in the columbus dataframe called "treat_new".
  columbus$treat_new <- NA
  
  # Second: Estimate the average treatment effect using treat_new. Take the difference
  # between the average outcome in the treatment group and the average outcome in the control group.
  # Store it as "ate"
  ate <- NA
  
  # Third: store it in the "ates" vector. I'll give this code to you.
  ates[i] <- ate
  
  
}

# Fourth: Plot the ATEs on a histogram. I'll give you this code.
ggplot(data.frame(ATE = ates), aes(x = ATE)) +
  geom_histogram() +
  geom_vline(xintercept = ate_columbus, color = "red", linetype = "dashed", size = 1) +
  annotate("text",
           x = ate_columbus + 0.005,
           y = 90,
           label = "ATE", color = "red", size = rel(4)
  ) +
  labs(x = "Null Distribution", y = "Count")

# Last: What is the one-tailed p-value? The two-tailed p-value? Is it statistically
# significant at the 0.05 level?
